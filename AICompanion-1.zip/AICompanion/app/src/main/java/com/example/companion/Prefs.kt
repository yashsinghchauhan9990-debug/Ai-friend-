package com.example.companion

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("companion", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun characterId(c: Context): String =
        sp(c).getString("character", Characters.all.first().id) ?: Characters.all.first().id

    fun setCharacterId(c: Context, id: String) = sp(c).edit().putString("character", id).apply()

    fun roam(c: Context): Boolean = sp(c).getBoolean("roam", true)
    fun setRoam(c: Context, v: Boolean) = sp(c).edit().putBoolean("roam", v).apply()

    fun voice(c: Context): Boolean = sp(c).getBoolean("voice", true)
    fun setVoice(c: Context, v: Boolean) = sp(c).edit().putBoolean("voice", v).apply()

    fun chatter(c: Context): Boolean = sp(c).getBoolean("chatter", true)
    fun setChatter(c: Context, v: Boolean) = sp(c).edit().putBoolean("chatter", v).apply()
}
