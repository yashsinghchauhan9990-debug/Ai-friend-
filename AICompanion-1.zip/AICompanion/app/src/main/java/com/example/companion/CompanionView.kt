package com.example.companion

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Draws a chibi character in code. Everything is drawn on a 100x100 grid and scaled to the view. */
class CompanionView(context: Context) : View(context) {

    enum class Mood { IDLE, WALK, TALK, HAPPY, ALERT, SLEEP, GRABBED }

    var look: Look = Characters.all.first().look
        set(value) {
            field = value
            invalidate()
        }

    var mood: Mood = Mood.IDLE
        set(value) {
            field = value
            invalidate()
        }

    var facingLeft: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 900
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedFraction
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = minOf(width, height) / 100f
        val wave = sin(phase * 2 * PI).toFloat()
        val bob = when (mood) {
            Mood.SLEEP -> wave
            Mood.WALK -> -abs(wave) * 3f
            Mood.HAPPY -> -abs(wave) * 5f
            else -> wave * 1.5f
        }
        canvas.save()
        if (facingLeft) canvas.scale(-1f, 1f, width / 2f, 0f)
        canvas.scale(s, s)
        canvas.translate(0f, bob)
        drawCharacter(canvas, wave)
        canvas.restore()
    }

    private fun drawCharacter(c: Canvas, wave: Float) {
        val sleepy = mood == Mood.SLEEP
        val armsUp = mood == Mood.HAPPY || mood == Mood.GRABBED || mood == Mood.ALERT
        val swing = if (mood == Mood.WALK) wave * 4f else 0f

        // legs
        fill(look.skin)
        c.drawRoundRect(RectF(38f, 90f + swing, 46f, 100f), 3f, 3f, paint)
        c.drawRoundRect(RectF(54f, 90f - swing, 62f, 100f), 3f, 3f, paint)

        // arms
        fill(look.skin)
        if (armsUp) {
            c.drawCircle(22f, 38f, 5.5f, paint)
            c.drawCircle(78f, 38f, 5.5f, paint)
        } else {
            c.drawCircle(26f, 74f + swing / 2f, 5f, paint)
            c.drawCircle(74f, 74f - swing / 2f, 5f, paint)
        }

        // body
        fill(look.outfit)
        c.drawRoundRect(RectF(30f, 64f, 70f, 96f), 10f, 10f, paint)
        fill(look.trim)
        c.drawRect(RectF(43f, 64f, 57f, 72f), paint)

        // hair behind the head
        fill(look.hairShade)
        when (look.style) {
            HairStyle.TWIN_TAILS -> {
                c.drawCircle(21f, 58f, 9f, paint)
                c.drawCircle(79f, 58f, 9f, paint)
            }
            HairStyle.LONG -> c.drawRoundRect(RectF(22f, 30f, 78f, 84f), 18f, 18f, paint)
            HairStyle.BOB -> c.drawRoundRect(RectF(24f, 24f, 76f, 62f), 16f, 16f, paint)
            HairStyle.SPIKY, HairStyle.MESSY -> c.drawCircle(50f, 40f, 28f, paint)
        }

        // head
        fill(look.skin)
        c.drawCircle(50f, 44f, 24f, paint)

        // fringe and style details
        fill(look.hair)
        c.drawArc(RectF(25f, 19f, 75f, 55f), 180f, 180f, true, paint)
        when (look.style) {
            HairStyle.SPIKY -> c.drawPath(spikes(), paint)
            HairStyle.MESSY -> {
                c.drawCircle(34f, 22f, 7f, paint)
                c.drawCircle(50f, 18f, 7f, paint)
                c.drawCircle(66f, 22f, 7f, paint)
            }
            else -> Unit
        }

        // cheeks
        fill(Color.argb(90, 255, 110, 140))
        c.drawCircle(34f, 54f, 4f, paint)
        c.drawCircle(66f, 54f, 4f, paint)

        drawEyes(c, sleepy)
        drawMouth(c)
        drawAccessory(c)

        // mood marks
        if (mood == Mood.ALERT) {
            fill(0xFFEF4444.toInt())
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 16f
            c.drawText("!", 84f, 18f, paint)
            paint.typeface = Typeface.DEFAULT
        }
        if (sleepy) {
            fill(0xFF6366F1.toInt())
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 11f
            c.drawText("z", 76f, 26f, paint)
            paint.textSize = 15f
            c.drawText("Z", 84f, 16f, paint)
            paint.typeface = Typeface.DEFAULT
        }
    }

    private fun drawEyes(c: Canvas, sleepy: Boolean) {
        val blink = System.currentTimeMillis() % 3200L < 130L
        if (sleepy || blink) {
            stroke(Color.rgb(40, 30, 30), 1.8f)
            for (ex in floatArrayOf(40f, 60f)) {
                c.drawArc(RectF(ex - 5f, 43f, ex + 5f, 51f), 200f, 140f, false, paint)
            }
            return
        }
        val big = mood == Mood.ALERT || mood == Mood.GRABBED
        val eh = if (big) 8f else 6f
        for (ex in floatArrayOf(40f, 60f)) {
            fill(Color.WHITE)
            c.drawOval(RectF(ex - 6f, 46f - eh, ex + 6f, 46f + eh), paint)
            fill(look.eyes)
            c.drawOval(RectF(ex - 4f, 46f - eh + 1f, ex + 4f, 46f + eh - 1f), paint)
            fill(Color.BLACK)
            c.drawCircle(ex, 46f, 2.2f, paint)
            fill(Color.WHITE)
            c.drawCircle(ex + 1.5f, 44f, 1.2f, paint)
        }
    }

    private fun drawMouth(c: Canvas) {
        fill(Color.rgb(120, 40, 50))
        when (mood) {
            Mood.TALK -> {
                val open = sin(phase * 4 * PI).toFloat() * 0.5f + 0.5f
                c.drawOval(RectF(46f, 55f, 54f, 57f + 4f * open), paint)
            }
            Mood.GRABBED, Mood.ALERT -> c.drawOval(RectF(47f, 55f, 53f, 60f), paint)
            Mood.SLEEP -> c.drawRect(RectF(47f, 57f, 53f, 58f), paint)
            else -> {
                stroke(Color.rgb(120, 40, 50), 1.8f)
                c.drawArc(RectF(44f, 50f, 56f, 60f), 20f, 140f, false, paint)
            }
        }
    }

    private fun drawAccessory(c: Canvas) {
        when (look.accessory) {
            Accessory.NONE -> Unit
            Accessory.CAT_EARS -> {
                fill(look.hair)
                c.drawPath(triangle(26f, 36f, 28f, 8f, 46f, 26f), paint)
                c.drawPath(triangle(74f, 36f, 72f, 8f, 54f, 26f), paint)
                fill(0xFFF9A8D4.toInt())
                c.drawPath(triangle(31f, 30f, 31f, 16f, 42f, 26f), paint)
                c.drawPath(triangle(69f, 30f, 69f, 16f, 58f, 26f), paint)
            }
            Accessory.HEADBAND -> {
                fill(look.outfit)
                c.drawRect(RectF(26f, 33f, 74f, 38f), paint)
            }
            Accessory.GLASSES -> {
                stroke(Color.rgb(30, 30, 40), 2f)
                c.drawCircle(40f, 46f, 9f, paint)
                c.drawCircle(60f, 46f, 9f, paint)
                c.drawLine(49f, 46f, 51f, 46f, paint)
            }
            Accessory.RIBBON -> {
                fill(look.outfit)
                c.drawPath(triangle(72f, 26f, 84f, 19f, 84f, 33f), paint)
                c.drawPath(triangle(72f, 26f, 60f, 19f, 60f, 33f), paint)
            }
            Accessory.HEADPHONES -> {
                stroke(Color.rgb(40, 40, 50), 4f)
                c.drawArc(RectF(20f, 16f, 80f, 66f), 180f, 180f, false, paint)
                fill(look.outfit)
                c.drawCircle(20f, 48f, 7f, paint)
                c.drawCircle(80f, 48f, 7f, paint)
            }
        }
    }

    private fun spikes(): Path = Path().apply {
        moveTo(26f, 40f)
        lineTo(22f, 16f)
        lineTo(38f, 30f)
        lineTo(46f, 12f)
        lineTo(54f, 30f)
        lineTo(64f, 12f)
        lineTo(70f, 30f)
        lineTo(80f, 16f)
        lineTo(74f, 40f)
        close()
    }

    private fun triangle(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float): Path = Path().apply {
        moveTo(x1, y1)
        lineTo(x2, y2)
        lineTo(x3, y3)
        close()
    }

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun stroke(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.color = color
    }
}
