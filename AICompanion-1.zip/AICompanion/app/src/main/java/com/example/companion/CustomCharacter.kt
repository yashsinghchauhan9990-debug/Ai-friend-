package com.example.companion

import android.content.Context
import android.graphics.Color

/** The "Make your own" character, built from the options chosen on the setup screen. */
object CustomCharacter {

    const val ID = "custom"

    val styleNames = listOf("Twin tails", "Spiky", "Long", "Bob", "Messy")
    val accessoryNames = listOf("None", "Cat ears", "Headband", "Glasses", "Ribbon", "Headphones")

    val hairNames = listOf("Dark brown", "Blonde", "Pink", "Blue", "Violet", "Silver", "Red", "Green")
    private val hairColors = intArrayOf(
        0xFF2B1B17.toInt(), 0xFFF8E7A1.toInt(), 0xFFFF8FB8.toInt(), 0xFF3B82F6.toInt(),
        0xFF8B5CF6.toInt(), 0xFF9CA3AF.toInt(), 0xFFEF4444.toInt(), 0xFF22C55E.toInt()
    )

    val outfitNames = listOf("Orange", "Blue", "Red", "Green", "Black", "Pink", "Light blue", "Violet")
    private val outfitColors = intArrayOf(
        0xFFF59E0B.toInt(), 0xFF3B82F6.toInt(), 0xFFEF4444.toInt(), 0xFF22C55E.toInt(),
        0xFF1F2937.toInt(), 0xFFF472B6.toInt(), 0xFF93C5FD.toInt(), 0xFF8B5CF6.toInt()
    )

    val eyeNames = listOf("Blue", "Green", "Yellow", "Brown", "Violet", "Sky")
    private val eyeColors = intArrayOf(
        0xFF4FA3FF.toInt(), 0xFF16A34A.toInt(), 0xFFFACC15.toInt(),
        0xFF5B3A29.toInt(), 0xFF8B5CF6.toInt(), 0xFF7DD3FC.toInt()
    )

    private fun prefs(c: Context) = c.getSharedPreferences("custom", Context.MODE_PRIVATE)

    fun index(c: Context, key: String): Int = prefs(c).getInt(key, 0)

    fun cycle(c: Context, key: String, size: Int) {
        prefs(c).edit().putInt(key, (index(c, key) + 1) % size).apply()
    }

    private fun shade(color: Int): Int = Color.rgb(
        (Color.red(color) * 0.75f).toInt(),
        (Color.green(color) * 0.75f).toInt(),
        (Color.blue(color) * 0.75f).toInt()
    )

    private fun outfit(c: Context): Int = outfitColors[index(c, "outfit") % outfitColors.size]

    fun look(c: Context): Look {
        val hair = hairColors[index(c, "hair") % hairColors.size]
        return Look(
            hair = hair,
            hairShade = shade(hair),
            skin = 0xFFFFE0CC.toInt(),
            eyes = eyeColors[index(c, "eye") % eyeColors.size],
            outfit = outfit(c),
            trim = 0xFFFFFFFF.toInt(),
            style = HairStyle.values()[index(c, "style") % HairStyle.values().size],
            accessory = Accessory.values()[index(c, "acc") % Accessory.values().size]
        )
    }

    fun resolve(c: Context, id: String): Character {
        if (id != ID) return Characters.byId(id)
        return Characters.byId("hana").copy(
            id = ID,
            name = "My buddy",
            tagline = "Made by you",
            color = outfit(c),
            look = look(c)
        )
    }
}
