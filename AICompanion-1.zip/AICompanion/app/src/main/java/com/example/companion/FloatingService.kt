package com.example.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.companion.CompanionView.Mood
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/**
 * The floating companion. It roams the screen, chats, talks, idles, sleeps, and reacts to
 * touch and to problems (battery, network, storage, and error screens from [ProblemWatcherService]).
 */
class FloatingService : Service() {

    companion object {
        @Volatile
        var instance: FloatingService? = null

        const val ACTION_STOP = "com.example.companion.STOP"
        private const val CHANNEL = "companion"
        private const val NOTIF_ID = 1
        private const val ALERT_COOLDOWN_MS = 120_000L
        private const val SLEEP_AFTER_MS = 120_000L
        private const val WALK_TICK_MS = 33L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var character: Character
    private lateinit var voice: Voice

    // the floating character
    private lateinit var petView: CompanionView
    private lateinit var petLp: WindowManager.LayoutParams
    private var petAdded = false
    private var targetX = 0
    private var targetY = 0
    private var pauseUntil = 0L
    private var dragging = false
    private var sleeping = false
    private var lastInteraction = 0L
    private var lastTapAt = 0L
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    // speech bubble
    private var speechView: TextView? = null
    private var speechLp: WindowManager.LayoutParams? = null
    private val hideSpeech = Runnable { removeSpeech() }

    // chat panel
    private var panel: LinearLayout? = null
    private var messageList: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var pending: Problem? = null
    private val lastFired = HashMap<String, Long>()

    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var batteryReceiver: BroadcastReceiver? = null

    private val openPanelRunnable = Runnable {
        val p = pending
        pending = null
        openPanel(p)
    }
    private val netLost = Runnable {
        onProblem(Problem(ProblemKind.NO_INTERNET, "The phone lost its connection."))
    }
    private val walkTick = object : Runnable {
        override fun run() {
            stepWalk()
            main.postDelayed(this, WALK_TICK_MS)
        }
    }
    private val chatterTick = object : Runnable {
        override fun run() {
            idleChatter()
            main.postDelayed(this, Random.nextLong(40_000, 90_000))
        }
    }
    private val sleepCheck = object : Runnable {
        override fun run() {
            val idle = SystemClock.elapsedRealtime() - lastInteraction > SLEEP_AFTER_MS
            if (!sleeping && !dragging && panel == null && idle) fallAsleep()
            main.postDelayed(this, 10_000)
        }
    }
    private val storageCheck = object : Runnable {
        override fun run() {
            checkStorage()
            main.postDelayed(this, 10 * 60_000L)
        }
    }

    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels
    private val petSize get() = dp(120)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        character = CustomCharacter.resolve(this, Prefs.characterId(this))
        voice = Voice(this)
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        lastInteraction = SystemClock.elapsedRealtime()
        buildPet()
        registerWatchers()
        main.postDelayed(walkTick, WALK_TICK_MS)
        main.postDelayed(chatterTick, 60_000)
        main.postDelayed(sleepCheck, 10_000)
        main.postDelayed(storageCheck, 15_000)
        main.postDelayed({ say(character.greeting) }, 800)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        netCallback?.let {
            runCatching { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        }
        batteryReceiver?.let { runCatching { unregisterReceiver(it) } }
        removeSpeech()
        panel?.let { safeRemove(it) }
        if (petAdded) safeRemove(petView)
        voice.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ foreground notification

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Companion", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("${character.name} is with you")
            .setContentText("Floating on your screen. Tap to open settings.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ floating character

    private fun buildPet() {
        petView = CompanionView(this).apply { look = character.look }
        petLp = WindowManager.LayoutParams(
            petSize, petSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - petSize
            y = screenH / 3
        }
        targetX = petLp.x
        targetY = petLp.y
        petView.setOnTouchListener { _, e -> onTouch(e) }
        wm.addView(petView, petLp)
        petAdded = true
    }

    private fun onTouch(e: MotionEvent): Boolean {
        lastInteraction = SystemClock.elapsedRealtime()
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX
                downRawY = e.rawY
                startX = petLp.x
                startY = petLp.y
                moved = false
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    dragging = true
                    main.removeCallbacks(openPanelRunnable)
                    petView.mood = Mood.GRABBED
                    say(character.grabbed.random())
                }
                if (dragging) {
                    petLp.x = (startX + dx).toInt()
                    petLp.y = (startY + dy).toInt()
                    wm.updateViewLayout(petView, petLp)
                    positionSpeech()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    dragging = false
                    petView.mood = Mood.IDLE
                    snapToEdge()
                    pauseUntil = SystemClock.elapsedRealtime() + 1500
                } else {
                    handleTap()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                petView.mood = Mood.IDLE
                return true
            }
        }
        return false
    }

    private fun handleTap() {
        if (sleeping) {
            wake()
            return
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 350) {
            // double tap: head pat
            main.removeCallbacks(openPanelRunnable)
            lastTapAt = 0L
            petView.mood = Mood.HAPPY
            say(character.pet.random())
            main.postDelayed({ if (!sleeping && !dragging) petView.mood = Mood.IDLE }, 1500)
        } else {
            lastTapAt = now
            main.postDelayed(openPanelRunnable, 350)
        }
    }

    private fun snapToEdge() {
        petLp.x = if (petLp.x + petSize / 2 < screenW / 2) 0 else screenW - petSize
        petLp.y = petLp.y.coerceIn(dp(40), (screenH - petSize - dp(70)).coerceAtLeast(dp(41)))
        wm.updateViewLayout(petView, petLp)
        targetX = petLp.x
        targetY = petLp.y
        positionSpeech()
    }

    /** Free roaming: walk toward a random spot, pause, then pick another. */
    private fun stepWalk() {
        val roaming = Prefs.roam(this) && !sleeping && !dragging && panel == null && petAdded
        if (!roaming) {
            if (petAdded && petView.mood == Mood.WALK) petView.mood = Mood.IDLE
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now < pauseUntil) return

        if (abs(petLp.x - targetX) < dp(3) && abs(petLp.y - targetY) < dp(3)) {
            val maxX = (screenW - petSize).coerceAtLeast(1)
            val maxY = (screenH - petSize - dp(70)).coerceAtLeast(dp(41))
            targetX = Random.nextInt(0, maxX)
            targetY = Random.nextInt(dp(40), maxY)
            pauseUntil = now + Random.nextLong(800, 3000)
            petView.mood = Mood.IDLE
            return
        }

        val dx = targetX - petLp.x
        val dy = targetY - petLp.y
        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val k = minOf(1f, dp(2).toFloat() / dist)
        petLp.x += (dx * k).toInt()
        petLp.y += (dy * k).toInt()
        if (abs(dx) > dp(1)) petView.facingLeft = dx < 0
        petView.mood = Mood.WALK
        wm.updateViewLayout(petView, petLp)
        positionSpeech()
    }

    private fun fallAsleep() {
        sleeping = true
        petView.mood = Mood.SLEEP
        say(character.sleepy.random(), speak = false)
    }

    private fun wake() {
        sleeping = false
        lastInteraction = SystemClock.elapsedRealtime()
        petView.mood = Mood.IDLE
        say(character.wake.random())
    }

    private fun idleChatter() {
        if (!Prefs.chatter(this) || sleeping || dragging || panel != null || speechView != null) return
        petView.mood = Mood.TALK
        say(character.idle.random())
        main.postDelayed({ if (!sleeping && !dragging && panel == null) petView.mood = Mood.IDLE }, 3000)
    }

    // ------------------------------------------------------------------ speech

    /** Shows a bubble above the character and, if enabled, speaks it. */
    private fun say(text: String, speak: Boolean = true) {
        if (!petAdded || panel != null) return
        showSpeech(text)
        if (speak && Prefs.voice(this)) voice.speak(text, character.pitch, character.rate, character.hinglish)
    }

    private fun showSpeech(text: String) {
        removeSpeech()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFF1B1B1F.toInt())
            maxWidth = dp(230)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(0xFFFFFFFF.toInt(), 16f, character.color, 2)
            setOnClickListener { handleTap() }
        }
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        speechView = tv
        speechLp = lp
        positionSpeech()
        wm.addView(tv, lp)
        main.removeCallbacks(hideSpeech)
        main.postDelayed(hideSpeech, 7_000)
    }

    private fun positionSpeech() {
        val sv = speechView ?: return
        val lp = speechLp ?: return
        val w = sv.measuredWidth
        val h = sv.measuredHeight
        val centerX = petLp.x + petSize / 2
        var x = if (centerX > screenW / 2) petLp.x + petSize - w else petLp.x
        x = x.coerceIn(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(8)))
        var y = petLp.y - h - dp(4)
        if (y < dp(24)) y = petLp.y + petSize + dp(4)
        lp.x = x
        lp.y = y
        if (sv.isAttachedToWindow) runCatching { wm.updateViewLayout(sv, lp) }
    }

    private fun removeSpeech() {
        main.removeCallbacks(hideSpeech)
        speechView?.let { safeRemove(it) }
        speechView = null
        speechLp = null
    }

    // ------------------------------------------------------------------ chat panel

    private fun openPanel(problem: Problem?) {
        if (panel == null) {
            removeSpeech()
            petView.visibility = View.GONE
            buildPanel()
            if (history.isEmpty()) addMessage(character.greeting, fromUser = false)
        }
        if (problem != null) askAboutProblem(problem)
    }

    private fun buildPanel() {
        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xF2161A2B.toInt(), 24f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(CompanionView(this).apply { look = character.look }, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(TextView(this).apply {
            text = "  ${character.name}"
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = if (Prefs.voice(this@FloatingService)) "🔊" else "🔇"
            textSize = 18f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener {
                val on = !Prefs.voice(this@FloatingService)
                Prefs.setVoice(this@FloatingService, on)
                text = if (on) "🔊" else "🔇"
            }
        })
        header.addView(TextView(this).apply {
            text = "🗑"
            textSize = 18f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { clearChat() }
        })
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        })
        root.addView(header)

        // messages
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        messageList = list
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(280)).apply {
            topMargin = dp(8)
        })

        // input row
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "Talk to ${character.name}…"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            background = roundBg(0x26FFFFFF, 20f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendFromInput()
                    true
                } else false
            }
        }
        input = et
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "➤"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = ovalBg(character.color)
            setOnClickListener { sendFromInput() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            screenW - dp(24), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
        wm.addView(root, lp)
        panel = root

        history.forEach { (role, text) -> addMessage(text, fromUser = role == "user") }
    }

    private fun closePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        messageList = null
        scroll = null
        input = null
        if (petAdded) petView.visibility = View.VISIBLE
        lastInteraction = SystemClock.elapsedRealtime()
    }

    private fun clearChat() {
        history.clear()
        messageList?.removeAllViews()
        addMessage(character.greeting, fromUser = false)
    }

    private fun addMessage(text: String, fromUser: Boolean): TextView? {
        val list = messageList ?: return null
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            setTextColor(Color.WHITE)
            maxWidth = (screenW * 0.72f).toInt()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(if (fromUser) character.color else 0x33FFFFFF, 16f)
        }
        list.addView(tv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(6)
            gravity = if (fromUser) Gravity.END else Gravity.START
        })
        scrollDown()
        return tv
    }

    private fun scrollDown() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendFromInput() {
        val et = input ?: return
        val text = et.text.toString().trim()
        if (text.isEmpty()) return
        et.setText("")
        ask(prompt = text, display = text, problem = null)
    }

    // ------------------------------------------------------------------ answers (online or offline)

    private fun systemPrompt(): String = """
        ${character.persona}

        You are a small floating companion living on the user's Android phone screen. Match the user's language (English, Hindi or Hinglish).
        Stay in character, but be genuinely useful. Keep replies under 70 words unless asked for more.
        When the user has a problem, give short numbered steps with exact Android Settings paths and mention that menu names vary by phone brand.
        You cannot tap or change anything on the phone yourself; you can only advise. Never ask for passwords, OTPs, PINs or card details.
    """.trimIndent()

    private fun askAboutProblem(p: Problem) {
        val app = p.pkg?.let { " It happened in the app: ${appLabel(it)}." } ?: ""
        val detail = if (p.detail.isNotBlank()) " Details: ${p.detail}" else ""
        ask(
            prompt = "My phone has a problem: ${p.kind.title}.$detail$app Please help me fix it, step by step.",
            display = "🆘 ${p.kind.title}",
            problem = p
        )
    }

    private fun ask(prompt: String, display: String, problem: Problem?) {
        addMessage(display, fromUser = true)
        history.add("user" to prompt)
        val typing = addMessage("…", fromUser = false)

        val key = Prefs.apiKey(this)
        if (key.isBlank() || !online()) {
            finish(typing, offlineReply(prompt, problem))
            return
        }
        scope.launch {
            val reply = AiClient.chat(key, systemPrompt(), history.takeLast(12)).getOrElse {
                "(offline mode) " + offlineReply(prompt, problem)
            }
            finish(typing, reply)
        }
    }

    private fun offlineReply(prompt: String, problem: Problem?): String =
        if (problem != null) LocalBrain.forProblem(character, problem)
        else LocalBrain.answer(character, prompt, phoneStatus())

    private fun finish(view: TextView?, reply: String) {
        view?.text = reply
        history.add("assistant" to reply)
        scrollDown()
        if (Prefs.voice(this)) voice.speak(reply, character.pitch, character.rate, character.hinglish)
    }

    private fun online(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun phoneStatus(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery $level%, " + if (online()) "internet connected" else "no internet"
    }

    // ------------------------------------------------------------------ problem handling

    /** Entry point for all detectors. Safe to call from any thread. */
    fun onProblem(p: Problem) {
        main.post {
            val key = p.kind.name + (p.pkg ?: "")
            val now = SystemClock.elapsedRealtime()
            val last = lastFired[key]
            if (last != null && now - last < ALERT_COOLDOWN_MS) return@post
            lastFired[key] = now
            if (!petAdded) return@post

            lastInteraction = now
            if (sleeping) wake()
            if (panel != null) {
                askAboutProblem(p)
                return@post
            }
            pending = p
            petView.mood = Mood.ALERT
            main.postDelayed({ if (!sleeping && !dragging) petView.mood = Mood.IDLE }, 4000)
            val detail = if (p.detail.isNotBlank()) "\n${p.detail.take(90)}" else ""
            say("${character.opener}\n⚠️ ${p.kind.title}$detail\nTap me and I'll help!")
        }
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun registerWatchers() {
        // low battery
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                onProblem(Problem(ProblemKind.LOW_BATTERY, "Battery is at $level%."))
            }
        }
        val filter = IntentFilter(Intent.ACTION_BATTERY_LOW)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        batteryReceiver = receiver

        // lost connection, debounced so Wi-Fi to mobile handovers don't trigger it
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                main.postDelayed(netLost, 5_000)
            }

            override fun onAvailable(network: Network) {
                main.removeCallbacks(netLost)
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb) }.onSuccess { netCallback = cb }
    }

    private fun checkStorage() {
        val free = runCatching { StatFs(Environment.getDataDirectory().path).availableBytes }
            .getOrDefault(Long.MAX_VALUE)
        if (free < 1_000_000_000L) {
            onProblem(Problem(ProblemKind.LOW_STORAGE, "Only %.1f GB free.".format(free / 1_000_000_000.0)))
        }
    }

    // ------------------------------------------------------------------ misc

    /** Called by the setup screen when the user changes character. */
    fun refreshCharacter() {
        main.post {
            character = CustomCharacter.resolve(this, Prefs.characterId(this))
            petView.look = character.look
            history.clear()
            pending = null
            if (panel != null) closePanel()
            say(character.greeting)
        }
    }

    private fun safeRemove(v: View) {
        runCatching { wm.removeView(v) }
    }
}
