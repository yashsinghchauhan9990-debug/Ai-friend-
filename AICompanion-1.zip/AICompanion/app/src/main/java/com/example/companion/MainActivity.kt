package com.example.companion

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Setup screen: API key, characters, custom look, behaviour, permissions, start and stop. */
class MainActivity : Activity() {

    private val grey = 0xFF5F6368.toInt()
    private val defaultAccent = 0xFF6366F1.toInt()

    private lateinit var keyInput: EditText
    private lateinit var overlayStatus: TextView
    private lateinit var a11yStatus: TextView
    private val cards = LinkedHashMap<String, LinearLayout>()
    private val accents = HashMap<String, Int>()
    private val previews = HashMap<String, CompanionView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        refreshCards()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshCards()
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        col.addView(label("AI Companion", 28f, bold = true))
        col.addView(label("A floating friend that roams your screen, chats, talks and helps when something goes wrong.", 14f, topDp = 4, color = grey))

        col.addView(section("1. Claude API key (optional)"))
        keyInput = EditText(this).apply {
            hint = "sk-ant-…"
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        col.addView(keyInput)
        col.addView(label("Without a key the companion still works offline with its help library. With a key and internet, it can chat freely. The key is stored only on this phone.", 12f, color = grey))

        col.addView(section("2. Choose your character"))
        Characters.all.forEach { addCard(col, it.id, it.name, it.tagline, it.look, it.color) }
        addCard(col, CustomCharacter.ID, "Make your own", "Pick the look with the options below", CustomCharacter.look(this), defaultAccent)

        col.addView(section("3. Customize your own character"))
        col.addView(customButton("style", "Hair style", CustomCharacter.styleNames))
        col.addView(customButton("hair", "Hair colour", CustomCharacter.hairNames))
        col.addView(customButton("outfit", "Outfit colour", CustomCharacter.outfitNames))
        col.addView(customButton("eye", "Eye colour", CustomCharacter.eyeNames))
        col.addView(customButton("acc", "Accessory", CustomCharacter.accessoryNames))

        col.addView(section("4. Behaviour"))
        col.addView(switchRow("Roam freely around the screen", Prefs.roam(this)) { Prefs.setRoam(this, it) })
        col.addView(switchRow("Speak replies out loud", Prefs.voice(this)) { Prefs.setVoice(this, it) })
        col.addView(switchRow("Idle chatter", Prefs.chatter(this)) { Prefs.setChatter(this, it) })

        col.addView(section("5. Permissions"))
        overlayStatus = label("", 14f)
        col.addView(overlayStatus)
        col.addView(button("Allow display over other apps") { openOverlaySettings() })
        a11yStatus = label("", 14f, topDp = 12)
        col.addView(a11yStatus)
        col.addView(button("Enable problem detection (optional)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(label(
            "Problem detection lets your companion notice crash and error screens. Battery, network and storage warnings work without it.",
            12f, color = grey
        ))

        col.addView(section("6. Go!"))
        col.addView(button("Start companion") { start() })
        col.addView(button("Stop companion") {
            stopService(Intent(this, FloatingService::class.java))
            toast("Companion stopped")
        })

        return ScrollView(this).apply {
            setBackgroundColor(0xFFF7F7FB.toInt())
            addView(col)
        }
    }

    private fun addCard(col: LinearLayout, id: String, name: String, tagline: String, look: Look, accent: Int) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(14), dp(8))
            setOnClickListener { select(id) }
        }
        val preview = CompanionView(this).apply { this.look = look }
        previews[id] = preview
        accents[id] = accent
        card.addView(preview, LinearLayout.LayoutParams(dp(72), dp(72)))

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        texts.addView(label(name, 16f, bold = true))
        texts.addView(label(tagline, 13f, color = grey))
        card.addView(texts)

        cards[id] = card
        col.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
    }

    private fun customButton(key: String, title: String, options: List<String>): Button {
        val button = Button(this).apply { isAllCaps = false }
        fun render() {
            button.text = "$title: ${options[CustomCharacter.index(this, key) % options.size]}"
        }
        render()
        button.setOnClickListener {
            CustomCharacter.cycle(this, key, options.size)
            Prefs.setCharacterId(this, CustomCharacter.ID)
            render()
            refreshCards()
            FloatingService.instance?.refreshCharacter()
        }
        return button
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = title
        textSize = 15f
        isChecked = checked
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, value -> onChange(value) }
    }

    private fun select(id: String) {
        Prefs.setCharacterId(this, id)
        refreshCards()
        FloatingService.instance?.refreshCharacter()
    }

    private fun start() {
        Prefs.setApiKey(this, keyInput.text.toString())
        if (!Settings.canDrawOverlays(this)) {
            toast("Please allow 'Display over other apps' first")
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        toast("${CustomCharacter.resolve(this, Prefs.characterId(this)).name} is now floating on your screen")
        moveTaskToBack(true)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        overlayStatus.text = if (overlay) "✅ Display over other apps: allowed" else "⬜ Display over other apps: not allowed yet"
        a11yStatus.text = if (isAccessibilityOn()) "✅ Problem detection: on" else "⬜ Problem detection: off (optional)"
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, ProblemWatcherService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) || it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun refreshCards() {
        val selected = Prefs.characterId(this)
        cards.forEach { (id, card) ->
            val accent = accents[id] ?: defaultAccent
            card.background = if (id == selected) {
                roundBg(0xFFFFFFFF.toInt(), 16f, accent, 3)
            } else {
                roundBg(0xFFFFFFFF.toInt(), 16f, 0xFFE0E0E6.toInt(), 1)
            }
        }
        previews[CustomCharacter.ID]?.look = CustomCharacter.look(this)
        previews[CustomCharacter.ID]?.let { accents[CustomCharacter.ID] = CustomCharacter.resolve(this, CustomCharacter.ID).color }
    }

    // ---- small UI helpers

    private fun section(text: String) = label(text, 18f, bold = true, topDp = 24)

    private fun label(text: String, size: Float, bold: Boolean = false, topDp: Int = 0, color: Int = Color.BLACK) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(topDp), 0, dp(4))
        }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
