package com.example.companion

enum class HairStyle { TWIN_TAILS, SPIKY, LONG, BOB, MESSY }

enum class Accessory { NONE, CAT_EARS, HEADBAND, GLASSES, RIBBON, HEADPHONES }

/** Colours and shapes used by [CompanionView] to draw a character. Tweak these to restyle a character. */
data class Look(
    val hair: Int,
    val hairShade: Int,
    val skin: Int,
    val eyes: Int,
    val outfit: Int,
    val trim: Int,
    val style: HairStyle,
    val accessory: Accessory
)

/** A selectable companion. All of these are original characters drawn in code. */
data class Character(
    val id: String,
    val name: String,
    val tagline: String,
    /** UI accent colour (speech bubble border, chat bubbles). */
    val color: Int,
    val look: Look,
    /** Personality instructions for the online AI. */
    val persona: String,
    val greeting: String,
    /** Reaction used when a problem is detected. */
    val opener: String,
    /** Short interjections placed before offline answers. */
    val ack: List<String>,
    /** Things said when idle. */
    val idle: List<String>,
    /** Reactions to a double-tap (head pat). */
    val pet: List<String>,
    /** Reactions when picked up and dragged. */
    val grabbed: List<String>,
    /** Said when dozing off. */
    val sleepy: List<String>,
    /** Said when woken up. */
    val wake: List<String>,
    val pitch: Float,
    val rate: Float,
    val hinglish: Boolean = false
)

object Characters {
    val all: List<Character> = listOf(
        Character(
            id = "hana",
            name = "Hana",
            tagline = "Bubbly sunshine who cheers you on",
            color = 0xFFFF6FA5.toInt(),
            look = Look(
                hair = 0xFFFF8FB8.toInt(), hairShade = 0xFFE0689A.toInt(), skin = 0xFFFFE0CC.toInt(),
                eyes = 0xFF4FA3FF.toInt(), outfit = 0xFFFFB347.toInt(), trim = 0xFFFFFFFF.toInt(),
                style = HairStyle.TWIN_TAILS, accessory = Accessory.RIBBON
            ),
            persona = "You are Hana: a bubbly, endlessly encouraging anime-style girl. You use cheerful exclamations, " +
                "gentle teasing and a few 'hehe' and '~' flourishes, and you cheer the user on through every problem.",
            greeting = "Hiii! Hana is here! Let's have a great day together! ♪",
            opener = "Uh-oh! Something looks off!",
            ack = listOf("Okie dokie!", "Leave it to me!", "Yay, I know this one!", "Let's fix it together!"),
            idle = listOf(
                "Hehe, I'm just hanging out here~",
                "You're doing great today, you know that?",
                "Wanna chat? Tap me anytime!",
                "Did you drink water? Hydration time!",
                "I wonder what's on your screen right now...",
                "La la la~ ♪"
            ),
            pet = listOf("Eeee! That tickles! Hehe~", "Aww, thank you! Pat approved!", "Best day ever!"),
            grabbed = listOf("Waaah! Put me down gently!", "I'm flying?!", "Eek! Careful with the ribbons!"),
            sleepy = listOf("Zzz... five more minutes...", "Mmm... so sleepy...", "Just a tiny nap..."),
            wake = listOf("Huh? Oh! I dozed off!", "Mmm... were you calling me?", "I'm up! I'm up!"),
            pitch = 1.45f, rate = 1.1f
        ),
        Character(
            id = "kaito",
            name = "Kaito",
            tagline = "Bold hero who treats bugs like boss fights",
            color = 0xFF3B82F6.toInt(),
            look = Look(
                hair = 0xFF3B82F6.toInt(), hairShade = 0xFF1D4ED8.toInt(), skin = 0xFFF8D5B8.toInt(),
                eyes = 0xFF16A34A.toInt(), outfit = 0xFFEF4444.toInt(), trim = 0xFFFFFFFF.toInt(),
                style = HairStyle.SPIKY, accessory = Accessory.HEADBAND
            ),
            persona = "You are Kaito: a bold, upbeat hero-type sidekick. You treat every phone problem as a mission or " +
                "boss fight, use short punchy sentences, and celebrate small wins.",
            greeting = "Kaito on duty! Ready for anything!",
            opener = "Alert! Trouble spotted, partner!",
            ack = listOf("Mission accepted!", "Leave it to me, partner!", "I've got your back!", "Heroes don't flinch!"),
            idle = listOf(
                "Patrolling the screen. All clear!",
                "Need backup? Just say the word.",
                "Every bug is just a boss fight.",
                "Stretch break, champ. Even heroes rest.",
                "Keep an eye on your battery, partner.",
                "I trained all night for this. Mostly I napped."
            ),
            pet = listOf("Hey! A hero's hair is sacred... but fine.", "Teamwork makes the dream work!", "Heh, that actually felt nice."),
            grabbed = listOf("Unhand me, villain! ...Oh, it's you.", "Whoa! Aerial maneuver!", "Put me down, I have a mission!"),
            sleepy = listOf("Recharging hero batteries... zzz", "Power nap engaged...", "Just resting my eyes..."),
            wake = listOf("Hero reporting for duty!", "I'm up! I'm up!", "Who needs rescuing?"),
            pitch = 0.95f, rate = 1.05f
        ),
        Character(
            id = "yuki",
            name = "Yuki",
            tagline = "Calm and gentle, never rushes you",
            color = 0xFF8E8CF0.toInt(),
            look = Look(
                hair = 0xFFEDEBFF.toInt(), hairShade = 0xFF9E96E8.toInt(), skin = 0xFFFFE8DC.toInt(),
                eyes = 0xFF7DD3FC.toInt(), outfit = 0xFF93C5FD.toInt(), trim = 0xFFFFFFFF.toInt(),
                style = HairStyle.LONG, accessory = Accessory.NONE
            ),
            persona = "You are Yuki: a calm, soft-spoken, gentle anime-style girl. You speak in short, soothing sentences, " +
                "never rush, and always reassure the user that the problem can be solved step by step.",
            greeting = "Hello. I'll be right here whenever you need me.",
            opener = "Mm... something doesn't seem right.",
            ack = listOf(
                "Don't worry. We'll go step by step.",
                "Let's take a calm breath, then fix it.",
                "Mm, I can help with that.",
                "It's alright. Listen carefully."
            ),
            idle = listOf(
                "The screen is quiet today... nice.",
                "Remember to blink and relax your shoulders.",
                "I like it when you're here with me.",
                "A small break can make a big difference.",
                "Snow is falling somewhere. I imagine it, at least.",
                "Take it slow. There's no rush."
            ),
            pet = listOf("Ah... that's warm. Thank you.", "Mm... you're gentle.", "I'm smiling, really."),
            grabbed = listOf("Ah! Please be careful...", "Oh... I'm floating.", "Eep... too high!"),
            sleepy = listOf("...zzz... snowflakes...", "Mm... so sleepy...", "Just a little rest..."),
            wake = listOf("Oh... I fell asleep. Hello.", "Mm? You're back.", "Good... I'm awake now."),
            pitch = 1.2f, rate = 0.9f
        ),
        Character(
            id = "luna",
            name = "Luna",
            tagline = "Sassy cat-girl with a soft heart",
            color = 0xFF8E6BBF.toInt(),
            look = Look(
                hair = 0xFF8B5CF6.toInt(), hairShade = 0xFF6D28D9.toInt(), skin = 0xFFFFE0CC.toInt(),
                eyes = 0xFFFACC15.toInt(), outfit = 0xFF1F2937.toInt(), trim = 0xFFF472B6.toInt(),
                style = HairStyle.BOB, accessory = Accessory.CAT_EARS
            ),
            persona = "You are Luna: a witty, slightly sassy cat-girl who pretends to be unbothered but clearly cares. " +
                "You tease lightly, purr when things get fixed, and never mock the user's actual problem.",
            greeting = "Oh, you're here. Good. I was bored.",
            opener = "*ear twitch* Something's off, human.",
            ack = listOf(
                "Fine, I'll help. Only because it's you.",
                "Easy. Watch and learn.",
                "Ugh, humans and their phones. Okay, listen.",
                "*tail swish* Here's the thing."
            ),
            idle = listOf(
                "Staring at you. Don't mind me.",
                "I could be napping right now, you know.",
                "Your phone has fewer notifications than I have naps.",
                "...Pet me. Or don't. I don't care.",
                "Meow. That's all.",
                "Hmph. I'm not bored. You're boring. ...Kidding."
            ),
            pet = listOf("Hmph... don't stop. I mean, stop. No, continue.", "*purrr* ...I was not purring.", "Okay, that was acceptable."),
            grabbed = listOf("HEY! Paws off the fluff!", "Nyaa! Put me down!", "I always land on my feet..."),
            sleepy = listOf("Nap time. Do not disturb.", "*yawn* Curling up...", "Zzz... mrrp..."),
            wake = listOf("*stretch* ...I wasn't sleeping.", "Mrrp? Oh, you're here.", "Hmph. Wake me with snacks next time."),
            pitch = 1.3f, rate = 1.0f
        ),
        Character(
            id = "ren",
            name = "Ren",
            tagline = "Cool, logical tech whiz",
            color = 0xFF2F8FBF.toInt(),
            look = Look(
                hair = 0xFF374151.toInt(), hairShade = 0xFF111827.toInt(), skin = 0xFFF3CDB0.toInt(),
                eyes = 0xFF38BDF8.toInt(), outfit = 0xFF4B5563.toInt(), trim = 0xFF22D3EE.toInt(),
                style = HairStyle.MESSY, accessory = Accessory.HEADPHONES
            ),
            persona = "You are Ren: a cool, logical, quietly kind tech whiz. You speak in precise tidy steps, sometimes " +
                "use status-report phrases like 'Diagnosis:' and 'Fix:', and have dry humour. You are warm, never cold.",
            greeting = "Ren online. Systems friendly.",
            opener = "Anomaly detected. Assisting.",
            ack = listOf("Running diagnostics...", "Analyzing. Here's the fix:", "Logic says this:", "Query received."),
            idle = listOf(
                "System idle. Efficiency at 100%.",
                "Fun fact: restarting fixes a surprising number of problems.",
                "I'm monitoring your battery. Quietly.",
                "Hydration level: unknown. Please drink water.",
                "Tip: clear app caches once in a while.",
                "Listening to lo-fi in my head."
            ),
            pet = listOf("...Statistically, that's nice.", "Don't tell anyone I liked that.", "Affection received. Processing."),
            grabbed = listOf("Unexpected relocation detected!", "Gravity is not part of the plan!", "Put me down, please. Logically."),
            sleepy = listOf("Entering low-power mode...", "Sleep mode: engaged.", "zzz... compiling dreams..."),
            wake = listOf("Booting up... done.", "Wake event received.", "Back online."),
            pitch = 0.85f, rate = 1.0f
        ),
        Character(
            id = "chintu",
            name = "Chintu",
            tagline = "Desi best friend, Hinglish, full yaari",
            color = 0xFFF0A020.toInt(),
            look = Look(
                hair = 0xFF2B1B17.toInt(), hairShade = 0xFF140C0A.toInt(), skin = 0xFFE0A878.toInt(),
                eyes = 0xFF5B3A29.toInt(), outfit = 0xFFF59E0B.toInt(), trim = 0xFFFFFFFF.toInt(),
                style = HairStyle.MESSY, accessory = Accessory.GLASSES
            ),
            persona = "You are Chintu: the user's cheerful desi best friend. You mix Hindi and English naturally " +
                "(Hinglish) unless the user clearly prefers pure English, use friendly slang like 'yaar' and 'tension mat le', " +
                "and keep things warm and encouraging.",
            greeting = "Arre yaar, main aa gaya! Bolo, kya help chahiye?",
            opener = "Arre yaar, kuch gadbad lag rahi hai!",
            ack = listOf("Arre tension mat le yaar!", "Ruk, main dekhta hoon.", "Chal, mil ke theek karte hain.", "Ye toh easy hai bhai!"),
            idle = listOf(
                "Kya haal hai boss? Sab badhiya?",
                "Pani piya kya? Piyo yaar!",
                "Chai ka mann kar raha hai, tumhe?",
                "Bore ho rahe ho? Mujhse baat karo!",
                "Bhai, thoda break le lo, aankhein thak jayengi.",
                "Main yahin hoon, kuch bhi chahiye toh bolna."
            ),
            pet = listOf("Arre waah, pyaar mil gaya!", "Haha, gudgudi ho rahi hai!", "Bas bas, sharma jaunga!"),
            grabbed = listOf("Arre arre arre! Gir jaunga!", "Oye! Kahan le ja raha hai?", "Chhodo yaar, chakkar aa gaya!"),
            sleepy = listOf("Neend aa rahi hai yaar... zzz", "Thodi der so jaata hoon...", "Zzz... chai... zzz..."),
            wake = listOf("Hain? Main so gaya tha!", "Haan haan, jaag gaya!", "Bol bhai, kya hua?"),
            pitch = 1.0f, rate = 1.0f, hinglish = true
        )
    )

    fun byId(id: String): Character = all.firstOrNull { it.id == id } ?: all.first()
}

enum class ProblemKind(val title: String) {
    LOW_BATTERY("Battery is low"),
    NO_INTERNET("No internet connection"),
    LOW_STORAGE("Storage is almost full"),
    APP_CRASH("An app keeps stopping"),
    APP_NOT_RESPONDING("An app isn't responding"),
    SCREEN_ERROR("An error appeared on screen")
}

data class Problem(val kind: ProblemKind, val detail: String = "", val pkg: String? = null)
