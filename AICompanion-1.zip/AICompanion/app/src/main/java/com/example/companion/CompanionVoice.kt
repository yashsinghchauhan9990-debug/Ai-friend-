package com.example.companion

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Speaks lines aloud using the phone's built-in voice, so it works offline. Each character has its own pitch and speed. */
class CompanionVoice(context: Context) {

    @Volatile
    private var ready = false

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String, c: Character) {
        val engine = tts ?: return
        if (!ready) return
        runCatching {
            engine.language = if (c.hinglish) Locale("en", "IN") else Locale.US
            engine.setPitch(c.pitch)
            engine.setSpeechRate(c.rate)
            engine.speak(text.take(400), TextToSpeech.QUEUE_FLUSH, null, "c${System.nanoTime()}")
        }
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
