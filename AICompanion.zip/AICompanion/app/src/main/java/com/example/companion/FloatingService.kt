package com.example.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.companion.CatView.Mood
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/**
 * Billu lives here. He walks along the edges of the screen when awake, sleeps when left alone,
 * stays out of the way while you use other apps, and reacts to taps, drags and problems.
 */
class FloatingService : Service() {

    companion object {
        @Volatile
        var instance: FloatingService? = null

        const val ACTION_STOP = "com.example.companion.STOP"
        private const val CHANNEL = "companion"
        private const val NOTIF_ID = 1
        private const val ALERT_COOLDOWN_MS = 120_000L
        private const val SLEEP_AFTER_MS = 180_000L
        private const val STEP_MS = 40L
    }

    private data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var voice: Voice

    // Billu's window and state
    private lateinit var cat: CatView
    private lateinit var catLp: WindowManager.LayoutParams
    private var catAdded = false
    private var perimeterT = 0f
    private var walkDir = 1f
    private var pauseUntil = 0L
    private var dragging = false
    private var sleeping = false
    private var moved = false
    private var lastInteraction = 0L
    private var lastTapAt = 0L
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    // speech bubble
    private var speechView: TextView? = null
    private var speechLp: WindowManager.LayoutParams? = null
    private val hideSpeech = Runnable { removeSpeech() }

    // chat panel
    private var panel: LinearLayout? = null
    private var messageList: LinearLayout? = null
    private var scroll: ScrollView? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var pending: Problem? = null
    private val lastFired = HashMap<String, Long>()

    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var batteryReceiver: BroadcastReceiver? = null

    private val openPanelRunnable = Runnable {
        val p = pending
        pending = null
        openPanel(p)
    }
    private val netLost = Runnable {
        onProblem(Problem(ProblemKind.NO_INTERNET, "The phone lost its connection."))
    }
    private val stepTick = object : Runnable {
        override fun run() {
            stepCat()
            main.postDelayed(this, STEP_MS)
        }
    }
    private val chatterTick = object : Runnable {
        override fun run() {
            idleMeow()
            main.postDelayed(this, Random.nextLong(60_000, 150_000))
        }
    }
    private val sleepCheck = object : Runnable {
        override fun run() {
            maybeSleep()
            main.postDelayed(this, 10_000)
        }
    }
    private val storageCheck = object : Runnable {
        override fun run() {
            checkStorage()
            main.postDelayed(this, 10 * 60_000L)
        }
    }

    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels
    private val catSize get() = dp(110)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        voice = Voice(this)
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        lastInteraction = SystemClock.elapsedRealtime()
        buildCat()
        registerWatchers()
        main.postDelayed(stepTick, STEP_MS)
        main.postDelayed(chatterTick, 60_000)
        main.postDelayed(sleepCheck, 10_000)
        main.postDelayed(storageCheck, 15_000)
        main.postDelayed({ say(Billu.GREETING) }, 800)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        netCallback?.let {
            runCatching { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        }
        batteryReceiver?.let { runCatching { unregisterReceiver(it) } }
        removeSpeech()
        panel?.let { safeRemove(it) }
        if (catAdded) safeRemove(cat)
        voice.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ foreground notification

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Billu", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("${Billu.NAME} is on your screen")
            .setContentText("Tap to open settings.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ Billu's window and walking

    private fun buildCat() {
        cat = CatView(this)
        catLp = WindowManager.LayoutParams(
            catSize, catSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - catSize
            y = dp(40)
        }
        perimeterT = nearestPerimeterT(catLp.x, catLp.y)
        cat.setOnTouchListener { _, e -> onTouch(e) }
        wm.addView(cat, catLp)
        catAdded = true
    }

    /** The screen edges Billu may walk on, leaving room for the status bar and navigation bar. */
    private fun bounds() = Bounds(
        left = 0,
        top = dp(40),
        right = (screenW - catSize).coerceAtLeast(1),
        bottom = (screenH - catSize - dp(70)).coerceAtLeast(dp(41))
    )

    /** Maps a distance along the edge loop (clockwise from the top-left corner) to a screen position. */
    private fun perimeterPoint(t: Float): Pair<Int, Int> {
        val b = bounds()
        val w = (b.right - b.left).toFloat()
        val h = (b.bottom - b.top).toFloat()
        val p = 2 * (w + h)
        val u = ((t % p) + p) % p
        return when {
            u < w -> Pair(b.left + u.toInt(), b.top)
            u < w + h -> Pair(b.right, b.top + (u - w).toInt())
            u < 2 * w + h -> Pair(b.right - (u - w - h).toInt(), b.bottom)
            else -> Pair(b.left, b.bottom - (u - 2 * w - h).toInt())
        }
    }

    /** Finds the edge loop distance closest to a position, used after Billu is dropped. */
    private fun nearestPerimeterT(x: Int, y: Int): Float {
        val b = bounds()
        val w = (b.right - b.left).toFloat()
        val h = (b.bottom - b.top).toFloat()
        val cx = x.coerceIn(b.left, b.right)
        val cy = y.coerceIn(b.top, b.bottom)
        val options = listOf(
            abs(y - b.top) to (cx - b.left).toFloat(),
            abs(x - b.right) to (w + (cy - b.top)),
            abs(y - b.bottom) to (w + h + (b.right - cx)),
            abs(x - b.left) to (2 * w + h + (b.bottom - cy))
        )
        return options.minBy { it.first }.second
    }

    /** Awake Billu walks slowly around the edges, sits now and then, and turns around sometimes. */
    private fun stepCat() {
        if (!catAdded) return
        val free = Prefs.roam(this) && !sleeping && !dragging && panel == null
        val now = SystemClock.elapsedRealtime()
        if (!free || now < pauseUntil) {
            if (cat.mood == Mood.WALK) cat.mood = Mood.IDLE
            return
        }
        if (Random.nextInt(0, 120) == 0) {
            pauseUntil = now + Random.nextLong(3_000, 7_000)
            cat.mood = Mood.IDLE
            return
        }
        if (Random.nextInt(0, 300) == 0) walkDir = -walkDir

        val before = perimeterPoint(perimeterT)
        perimeterT += walkDir * dp(1).toFloat()
        val after = perimeterPoint(perimeterT)
        val dx = after.first - before.first
        if (dx != 0) cat.facingLeft = dx < 0
        catLp.x = after.first
        catLp.y = after.second
        cat.mood = Mood.WALK
        wm.updateViewLayout(cat, catLp)
        positionSpeech()
    }

    private fun maybeSleep() {
        val quiet = SystemClock.elapsedRealtime() - lastInteraction > SLEEP_AFTER_MS
        if (!catAdded || sleeping || dragging || panel != null || !quiet) return
        sleeping = true
        cat.mood = Mood.SLEEP
        say(Billu.sleepy.random(), speak = false)
    }

    private fun wake(silent: Boolean = false) {
        sleeping = false
        lastInteraction = SystemClock.elapsedRealtime()
        cat.mood = Mood.IDLE
        if (!silent) say(Billu.wake.random(), speak = false)
    }

    // ------------------------------------------------------------------ touch

    private fun onTouch(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                lastInteraction = SystemClock.elapsedRealtime()
                downRawX = e.rawX
                downRawY = e.rawY
                startX = catLp.x
                startY = catLp.y
                moved = false
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!moved && hypot(dx.toDouble(), dy.toDouble()) > slop) {
                    moved = true
                    dragging = true
                    main.removeCallbacks(openPanelRunnable)
                    if (sleeping) wake(silent = true)
                    cat.mood = Mood.ALERT
                    say(Billu.grabbed.random(), speak = false)
                }
                if (dragging) {
                    catLp.x = (startX + dx).toInt()
                    catLp.y = (startY + dy).toInt()
                    wm.updateViewLayout(cat, catLp)
                    positionSpeech()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    dragging = false
                    perimeterT = nearestPerimeterT(catLp.x, catLp.y)
                    val p = perimeterPoint(perimeterT)
                    catLp.x = p.first
                    catLp.y = p.second
                    wm.updateViewLayout(cat, catLp)
                    positionSpeech()
                    cat.mood = Mood.IDLE
                    pauseUntil = SystemClock.elapsedRealtime() + 1500
                    say(Billu.landed.random(), speak = false)
                } else {
                    handleTap()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                cat.mood = Mood.IDLE
                return true
            }
        }
        return false
    }

    private fun handleTap() {
        if (sleeping) {
            wake()
            return
        }
        lastInteraction = SystemClock.elapsedRealtime()
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 350) {
            // double tap: a head scratch makes Billu purr
            main.removeCallbacks(openPanelRunnable)
            lastTapAt = 0L
            cat.mood = Mood.PURR
            pauseUntil = SystemClock.elapsedRealtime() + 2500
            say(Billu.pet.random(), speak = false)
            main.postDelayed({ if (!sleeping && !dragging) cat.mood = Mood.IDLE }, 2500)
        } else {
            // single tap: Billu looks up at you, then the chat opens
            lastTapAt = now
            cat.mood = Mood.ALERT
            pauseUntil = SystemClock.elapsedRealtime() + 1500
            main.postDelayed({ if (!sleeping && !dragging && cat.mood == Mood.ALERT) cat.mood = Mood.IDLE }, 1500)
            main.postDelayed(openPanelRunnable, 350)
        }
    }

    // ------------------------------------------------------------------ speech

    /** Shows a bubble above Billu and, if enabled, speaks it. */
    private fun say(text: String, speak: Boolean = true) {
        if (!catAdded || panel != null) return
        showSpeech(text)
        if (speak && Prefs.voice(this)) voice.speak(text, Billu.PITCH, Billu.RATE)
    }

    private fun showSpeech(text: String) {
        removeSpeech()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFF1B1B1F.toInt())
            maxWidth = dp(230)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(0xFFFFFFFF.toInt(), 16f, Billu.COLOR, 2)
            setOnClickListener { handleTap() }
        }
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        speechView = tv
        speechLp = lp
        positionSpeech()
        wm.addView(tv, lp)
        main.removeCallbacks(hideSpeech)
        main.postDelayed(hideSpeech, 7_000)
    }

    private fun positionSpeech() {
        val sv = speechView ?: return
        val lp = speechLp ?: return
        val w = sv.measuredWidth
        val h = sv.measuredHeight
        val centerX = catLp.x + catSize / 2
        var x = if (centerX > screenW / 2) catLp.x + catSize - w else catLp.x
        x = x.coerceIn(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(8)))
        var y = catLp.y - h - dp(4)
        if (y < dp(24)) y = catLp.y + catSize + dp(4)
        lp.x = x
        lp.y = y
        if (sv.isAttachedToWindow) runCatching { wm.updateViewLayout(sv, lp) }
    }

    private fun removeSpeech() {
        main.removeCallbacks(hideSpeech)
        speechView?.let { safeRemove(it) }
        speechView = null
        speechLp = null
    }

    /** Occasional cat noises and remarks when awake and nothing else is happening. */
    private fun idleMeow() {
        if (!Prefs.chatter(this) || !catAdded || sleeping || dragging || panel != null || speechView != null) return
        say(Billu.idle.random(), speak = false)
    }

    // ------------------------------------------------------------------ chat panel

    private fun openPanel(problem: Problem?) {
        if (panel == null) {
            removeSpeech()
            cat.visibility = View.GONE
            buildPanel()
            if (history.isEmpty()) addMessage(Billu.GREETING, fromUser = false)
        }
        if (problem != null) askAboutProblem(problem)
    }

    private fun buildPanel() {
        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xF2161A2B.toInt(), 24f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(CatView(this).apply { mood = Mood.IDLE }, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(TextView(this).apply {
            text = "  ${Billu.NAME}"
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = if (Prefs.voice(this@FloatingService)) "🔊" else "🔇"
            textSize = 18f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener {
                val on = !Prefs.voice(this@FloatingService)
                Prefs.setVoice(this@FloatingService, on)
                text = if (on) "🔊" else "🔇"
            }
        })
        header.addView(TextView(this).apply {
            text = "🗑"
            textSize = 18f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { clearChat() }
        })
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        })
        root.addView(header)

        // messages
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        messageList = list
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(280)).apply {
            topMargin = dp(8)
        })

        // input row
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "Talk to ${Billu.NAME}…"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            background = roundBg(0x26FFFFFF, 20f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendFromInput(this)
                    true
                } else false
            }
        }
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "➤"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = ovalBg(Billu.COLOR)
            setOnClickListener { sendFromInput(et) }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            screenW - dp(24), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
        wm.addView(root, lp)
        panel = root

        history.forEach { (role, text) -> addMessage(text, fromUser = role == "user") }
    }

    private fun closePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        messageList = null
        scroll = null
        if (catAdded) cat.visibility = View.VISIBLE
        lastInteraction = SystemClock.elapsedRealtime()
    }

    private fun clearChat() {
        history.clear()
        messageList?.removeAllViews()
        addMessage(Billu.GREETING, fromUser = false)
    }

    private fun addMessage(text: String, fromUser: Boolean): TextView? {
        val list = messageList ?: return null
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            setTextColor(Color.WHITE)
            maxWidth = (screenW * 0.72f).toInt()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(if (fromUser) Billu.COLOR else 0x33FFFFFF, 16f)
        }
        list.addView(tv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(6)
            gravity = if (fromUser) Gravity.END else Gravity.START
        })
        scrollDown()
        return tv
    }

    private fun scrollDown() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendFromInput(et: EditText) {
        val text = et.text.toString().trim()
        if (text.isEmpty()) return
        et.setText("")
        ask(prompt = text, display = text, problem = null)
    }

    // ------------------------------------------------------------------ answers (online or offline)

    private fun systemPrompt(): String = """
        ${Billu.PERSONA}

        You are a small cat living on the user's Android phone screen. Stay in character, but be genuinely useful.
        When the user has a problem, give short numbered steps with exact Android Settings paths and mention that menu names vary by phone brand.
        You cannot tap or change anything on the phone yourself; you can only advise. Never ask for passwords, OTPs, PINs or card details.
    """.trimIndent()

    private fun askAboutProblem(p: Problem) {
        val app = p.pkg?.let { " It happened in the app: ${appLabel(it)}." } ?: ""
        val detail = if (p.detail.isNotBlank()) " Details: ${p.detail}" else ""
        ask(
            prompt = "My phone has a problem: ${p.kind.title}.$detail$app Please help me fix it, step by step.",
            display = "🆘 ${p.kind.title}",
            problem = p
        )
    }

    private fun ask(prompt: String, display: String, problem: Problem?) {
        addMessage(display, fromUser = true)
        history.add("user" to prompt)
        val typing = addMessage("…", fromUser = false)

        val key = Prefs.apiKey(this)
        if (key.isBlank() || !online()) {
            finish(typing, offlineReply(prompt, problem))
            return
        }
        scope.launch {
            val reply = AiClient.chat(key, systemPrompt(), history.takeLast(12)).getOrElse {
                "(offline mode) " + offlineReply(prompt, problem)
            }
            finish(typing, reply)
        }
    }

    private fun offlineReply(prompt: String, problem: Problem?): String =
        if (problem != null) LocalBrain.forProblem(problem)
        else LocalBrain.answer(prompt, phoneStatus())

    private fun finish(view: TextView?, reply: String) {
        view?.text = reply
        history.add("assistant" to reply)
        scrollDown()
        if (Prefs.voice(this)) voice.speak(reply, Billu.PITCH, Billu.RATE)
    }

    private fun online(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun phoneStatus(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery $level%, " + if (online()) "internet connected" else "no internet"
    }

    // ------------------------------------------------------------------ problem handling

    /** Entry point for all detectors. Safe to call from any thread. */
    fun onProblem(p: Problem) {
        main.post {
            val key = p.kind.name + (p.pkg ?: "")
            val now = SystemClock.elapsedRealtime()
            val last = lastFired[key]
            if (last != null && now - last < ALERT_COOLDOWN_MS) return@post
            lastFired[key] = now
            if (!catAdded) return@post

            lastInteraction = now
            if (sleeping) wake(silent = true)
            if (panel != null) {
                askAboutProblem(p)
                return@post
            }
            pending = p
            cat.mood = Mood.SAD
            main.postDelayed({ if (!sleeping && !dragging && cat.mood == Mood.SAD) cat.mood = Mood.IDLE }, 4000)
            val detail = if (p.detail.isNotBlank()) "\n${p.detail.take(90)}" else ""
            say("${Billu.OPENER}\n⚠️ ${p.kind.title}$detail\nTap me and I'll help!", speak = false)
        }
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun registerWatchers() {
        // low battery
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                onProblem(Problem(ProblemKind.LOW_BATTERY, "Battery is at $level%."))
            }
        }
        val filter = IntentFilter(Intent.ACTION_BATTERY_LOW)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        batteryReceiver = receiver

        // lost connection, debounced so Wi-Fi to mobile handovers don't trigger it
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                main.postDelayed(netLost, 5_000)
            }

            override fun onAvailable(network: Network) {
                main.removeCallbacks(netLost)
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb) }.onSuccess { netCallback = cb }
    }

    private fun checkStorage() {
        val free = runCatching { StatFs(Environment.getDataDirectory().path).availableBytes }
            .getOrDefault(Long.MAX_VALUE)
        if (free < 1_000_000_000L) {
            onProblem(Problem(ProblemKind.LOW_STORAGE, "Only %.1f GB free.".format(free / 1_000_000_000.0)))
        }
    }

    // ------------------------------------------------------------------ misc

    private fun safeRemove(v: View) {
        runCatching { wm.removeView(v) }
    }
}
