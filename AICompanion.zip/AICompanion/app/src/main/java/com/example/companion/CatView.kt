package com.example.companion

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Billu, drawn in code as a side-view ginger cat facing right. Drawn on a 100x100 grid. */
class CatView(context: Context) : View(context) {

    enum class Mood { SLEEP, IDLE, WALK, PURR, ALERT }

    var mood: Mood = Mood.IDLE
        set(value) {
            field = value
            invalidate()
        }

    var facingLeft: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyColor = 0xFFE8A04C.toInt()
    private val stripeColor = 0xFFB86B2A.toInt()
    private val bellyColor = 0xFFFFF1DC.toInt()
    private val earInner = 0xFFF5A3A3.toInt()
    private val eyeColor = 0xFF7BC67B.toInt()
    private val noseColor = Color.rgb(240, 130, 140)
    private val lineColor = Color.rgb(60, 35, 20)

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedFraction
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = minOf(width, height) / 100f
        val wave = sin(phase * 2 * PI).toFloat()
        canvas.save()
        if (facingLeft) canvas.scale(-1f, 1f, width / 2f, 0f)
        canvas.scale(s, s)
        if (mood == Mood.SLEEP) drawLoaf(canvas, wave) else drawStanding(canvas, wave)
        canvas.restore()
    }

    private fun drawStanding(c: Canvas, wave: Float) {
        val walking = mood == Mood.WALK
        val blink = System.currentTimeMillis() % 3200L < 130L
        val bob = if (walking) -abs(wave) * 2f else wave * 0.6f
        c.save()
        c.translate(0f, bob)

        // tail: swishes when idle, puffs up when alert
        val sway = if (mood == Mood.ALERT) -6f else wave * 4f
        stroke(bodyColor, if (mood == Mood.ALERT) 7f else 5f)
        paint.strokeCap = Paint.Cap.ROUND
        c.drawPath(Path().apply {
            moveTo(24f, 58f)
            cubicTo(4f, 56f, 2f + sway / 2f, 32f, 14f + sway, 24f)
        }, paint)
        paint.strokeCap = Paint.Cap.BUTT

        // legs: diagonal pairs swing when walking
        val swing = if (walking) wave * 5f else 0f
        fill(bodyColor)
        leg(c, 28f, 66f + swing)
        leg(c, 40f, 66f - swing)
        leg(c, 58f, 66f - swing)
        leg(c, 68f, 66f + swing)

        // body and belly
        fill(bodyColor)
        c.drawOval(RectF(22f, 46f, 76f, 72f), paint)
        fill(bellyColor)
        c.drawOval(RectF(40f, 58f, 70f, 72f), paint)
        stroke(stripeColor, 2.5f)
        for (x in floatArrayOf(32f, 42f, 52f)) c.drawLine(x, 48f, x - 3f, 56f, paint)

        // head and ears
        fill(bodyColor)
        c.drawCircle(74f, 38f, 15f, paint)
        c.drawPath(triangle(61f, 32f, 62f, 13f, 73f, 26f), paint)
        c.drawPath(triangle(74f, 25f, 81f, 11f, 86f, 30f), paint)
        fill(earInner)
        c.drawPath(triangle(64f, 30f, 65f, 19f, 71f, 27f), paint)
        c.drawPath(triangle(76f, 26f, 81f, 17f, 83f, 28f), paint)
        stroke(stripeColor, 2f)
        c.drawLine(70f, 24f, 72f, 29f, paint)
        c.drawLine(76f, 24f, 77f, 29f, paint)

        // eyes: closed when purring or blinking
        if (mood == Mood.PURR || blink) {
            stroke(lineColor, 2f)
            c.drawArc(RectF(72f, 34f, 80f, 42f), 20f, 140f, false, paint)
        } else {
            fill(eyeColor)
            c.drawOval(RectF(72f, 32f, 80f, 42f), paint)
            fill(Color.BLACK)
            c.drawOval(RectF(75.2f, 33f, 77.2f, 41f), paint)
            fill(Color.WHITE)
            c.drawCircle(78f, 34.5f, 1.2f, paint)
        }

        // nose, whiskers, collar and bell
        fill(noseColor)
        c.drawPath(triangle(85f, 40f, 89f, 40f, 87f, 43f), paint)
        stroke(Color.rgb(90, 60, 40), 1f)
        c.drawLine(84f, 44f, 100f, 41f, paint)
        c.drawLine(84f, 46f, 100f, 47f, paint)
        stroke(0xFFE11D48.toInt(), 3f)
        c.drawLine(63f, 50f, 79f, 54f, paint)
        fill(0xFFFACC15.toInt())
        c.drawCircle(71f, 56f, 2.6f, paint)

        // marks
        if (mood == Mood.ALERT) {
            fill(0xFFEF4444.toInt())
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 14f
            c.drawText("!", 90f, 12f, paint)
            paint.typeface = Typeface.DEFAULT
        }
        if (mood == Mood.PURR) {
            fill(0xFFF472B6.toInt())
            paint.textSize = 10f
            c.drawText("♥", 88f, 16f, paint)
        }
        c.restore()
    }

    /** Curled-up loaf with closed eyes and a slow breathing motion. */
    private fun drawLoaf(c: Canvas, wave: Float) {
        c.save()
        c.translate(0f, wave * 1.2f)

        // tail wrapped in front
        stroke(bodyColor, 5f)
        paint.strokeCap = Paint.Cap.ROUND
        c.drawPath(Path().apply {
            moveTo(20f, 80f)
            cubicTo(2f, 80f, 6f, 92f, 34f, 88f)
        }, paint)
        paint.strokeCap = Paint.Cap.BUTT

        // body with stripes
        fill(bodyColor)
        c.drawOval(RectF(14f, 60f, 74f, 88f), paint)
        stroke(stripeColor, 2.5f)
        c.drawLine(28f, 64f, 24f, 74f, paint)
        c.drawLine(40f, 62f, 36f, 74f, paint)
        c.drawLine(52f, 63f, 48f, 74f, paint)

        // ears and head resting on the paws
        fill(bodyColor)
        c.drawPath(triangle(70f, 58f, 70f, 42f, 80f, 52f), paint)
        c.drawPath(triangle(81f, 52f, 88f, 40f, 90f, 58f), paint)
        c.drawCircle(80f, 62f, 13f, paint)

        // closed eyes and nose
        stroke(lineColor, 2f)
        c.drawArc(RectF(74f, 58f, 80f, 64f), 20f, 140f, false, paint)
        c.drawArc(RectF(82f, 58f, 88f, 64f), 20f, 140f, false, paint)
        fill(noseColor)
        c.drawPath(triangle(85f, 67f, 89f, 67f, 87f, 70f), paint)

        // zzz
        fill(0xFF6366F1.toInt())
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 10f
        c.drawText("z", 94f, 44f + wave, paint)
        paint.textSize = 14f
        c.drawText("Z", 90f, 30f + wave, paint)
        paint.typeface = Typeface.DEFAULT
        c.restore()
    }

    private fun leg(c: Canvas, x: Float, top: Float) {
        c.drawRoundRect(RectF(x, top, x + 7f, 86f), 3f, 3f, paint)
    }

    private fun triangle(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float): Path = Path().apply {
        moveTo(x1, y1)
        lineTo(x2, y2)
        lineTo(x3, y3)
        close()
    }

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun stroke(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.color = color
    }
}
