package com.example.companion

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Billu, shown with the cut-out artwork from the character sheet.
 * Full-body poses (idle, walk, sleep) stand on the bottom edge.
 * Expressions (purr = happy, alert = surprised, sad) show the head, centred.
 */
class CatView(context: Context) : View(context) {

    enum class Mood { SLEEP, IDLE, WALK, PURR, ALERT, SAD }

    var mood: Mood = Mood.IDLE
        set(value) {
            field = value
            invalidate()
        }

    var facingLeft: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dest = RectF()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedFraction
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = sprite(spriteFor(mood)) ?: return
        val wave = sin(phase * 2 * PI).toFloat()

        // fit the image inside the view without distorting it
        val scale = minOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        val left = (width - dw) / 2f

        val fullBody = mood == Mood.IDLE || mood == Mood.WALK || mood == Mood.SLEEP
        val bob = when (mood) {
            Mood.WALK -> -abs(wave) * dpf(4)   // little hops while walking
            Mood.SLEEP -> wave * dpf(1)        // slow breathing
            else -> wave * dpf(2)              // gentle sway
        }
        val top = (if (fullBody) height - dh else (height - dh) / 2f) + bob

        dest.set(left, top, left + dw, top + dh)
        canvas.save()
        if (facingLeft) canvas.scale(-1f, 1f, width / 2f, 0f)
        canvas.drawBitmap(bmp, null, dest, paint)
        canvas.restore()
    }

    private fun spriteFor(m: Mood): Int = when (m) {
        Mood.SLEEP -> R.drawable.billu_sleep
        Mood.WALK -> R.drawable.billu_walk
        Mood.IDLE -> R.drawable.billu_idle
        Mood.PURR -> R.drawable.billu_happy
        Mood.ALERT -> R.drawable.billu_surprised
        Mood.SAD -> R.drawable.billu_sad
    }

    private fun sprite(id: Int): Bitmap? {
        cache[id]?.let { return it }
        val bmp = BitmapFactory.decodeResource(resources, id) ?: return null
        cache[id] = bmp
        return bmp
    }

    private fun dpf(v: Int): Float = resources.displayMetrics.density * v

    companion object {
        /** Decoded images are shared by every CatView so they are only loaded once. */
        private val cache = HashMap<Int, Bitmap>()
    }
}
