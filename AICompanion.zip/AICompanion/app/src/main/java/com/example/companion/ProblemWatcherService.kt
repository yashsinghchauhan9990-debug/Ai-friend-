package com.example.companion

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Notices error dialogs and crash/ANR messages in other apps and tells the companion.
 *
 * Privacy: only short error phrases are matched on the device. Editable fields and password
 * fields are skipped, and nothing leaves the phone unless the user taps the companion to ask for help.
 */
class ProblemWatcherService : AccessibilityService() {

    private class Rule(val kind: ProblemKind, val regex: Regex, val smallWindowOnly: Boolean)

    private val rules = listOf(
        Rule(ProblemKind.APP_NOT_RESPONDING, Regex("isn'?t responding|not responding", RegexOption.IGNORE_CASE), false),
        Rule(ProblemKind.APP_CRASH, Regex("keeps stopping|has stopped|stopped working|has crashed|crashed", RegexOption.IGNORE_CASE), false),
        Rule(
            ProblemKind.LOW_STORAGE,
            Regex("storage (is )?full|not enough (storage|space)|insufficient storage|storage space running out", RegexOption.IGNORE_CASE),
            false
        ),
        // Softer phrases only count in small windows (dialogs, error screens) to avoid matching chat text or articles.
        Rule(
            ProblemKind.NO_INTERNET,
            Regex("no internet|no connection|can'?t connect|check your (internet|connection)|you'?re offline|you are offline", RegexOption.IGNORE_CASE),
            true
        ),
        Rule(
            ProblemKind.SCREEN_ERROR,
            Regex("something went wrong|an error occurred|unable to load|failed to load|couldn'?t load|error code", RegexOption.IGNORE_CASE),
            true
        )
    )

    private var lastScan = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return

        val now = System.currentTimeMillis()
        if (now - lastScan < 1_500) return
        lastScan = now

        val service = FloatingService.instance ?: return
        val root = rootInActiveWindow ?: event.source ?: return

        val texts = ArrayList<String>()
        collectTexts(root, texts, limit = 150)
        if (texts.isEmpty()) return
        val small = texts.size <= 40

        for (rule in rules) {
            if (rule.smallWindowOnly && !small) continue
            val hit = texts.firstOrNull { rule.regex.containsMatchIn(it) } ?: continue
            service.onProblem(Problem(rule.kind, hit.take(120), pkg))
            return
        }
    }

    private fun collectTexts(node: AccessibilityNodeInfo?, out: MutableList<String>, limit: Int) {
        if (node == null || out.size >= limit) return
        if (!node.isEditable && !node.isPassword) {
            val t = node.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && t.length <= 300) out.add(t)
        }
        for (i in 0 until node.childCount) {
            if (out.size >= limit) return
            collectTexts(node.getChild(i), out, limit)
        }
    }

    override fun onInterrupt() = Unit
}
