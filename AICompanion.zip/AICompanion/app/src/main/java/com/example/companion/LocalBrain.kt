package com.example.companion

/**
 * Works with no internet and no API key. Answers common phone problems from a built-in
 * help library and makes simple small talk in Billu's voice.
 */
object LocalBrain {

    private class Topic(val keys: List<String>, val answer: String, val showStatus: Boolean = false)

    private const val BATTERY = "Battery tips:\n" +
        "1. Settings → Battery → turn on Battery Saver.\n" +
        "2. Lower screen brightness, or turn on Adaptive brightness.\n" +
        "3. Open Battery usage and restrict the apps that drain the most.\n" +
        "4. Turn off Bluetooth, location and hotspot when you don't need them."

    private const val SLOW = "Slow phone fixes:\n" +
        "1. Restart the phone.\n" +
        "2. Keep at least 10% storage free.\n" +
        "3. Close heavy apps from Recents.\n" +
        "4. Clear the cache of the slowest app.\n" +
        "5. Update apps and the system."

    private const val CONNECTION = "Connection fixes:\n" +
        "1. Turn Airplane mode on, wait 5 seconds, then turn it off.\n" +
        "2. Forget the Wi-Fi network and join it again.\n" +
        "3. Restart the router if you're on Wi-Fi.\n" +
        "4. Check that mobile data is on and your data limit isn't reached."

    private const val STORAGE = "Storage tips:\n" +
        "1. Settings → Storage shows what's taking space.\n" +
        "2. Delete old downloads and WhatsApp media.\n" +
        "3. Clear browser cache.\n" +
        "4. Move photos and videos to Google Photos or a computer."

    private const val HEAT = "Overheating fixes:\n" +
        "1. Close games and heavy apps.\n" +
        "2. Take off the case and move to shade.\n" +
        "3. Turn off hotspot and unused features.\n" +
        "4. If it stays hot while idle, stop charging and check with a technician."

    private const val CRASH = "App crashing fixes:\n" +
        "1. Update the app in the Play Store.\n" +
        "2. Settings → Apps → the app → Storage → Clear cache.\n" +
        "3. Restart the phone.\n" +
        "4. If it still happens, uninstall and reinstall the app."

    private const val NOT_RESPONDING = "Tap Wait for a few seconds. If it stays frozen, close it from Recents " +
        "and reopen it. Restart the phone if many apps freeze."

    private const val SCREEN_ERROR = "Go back and try once more. Check your internet, update the app, " +
        "and clear its cache if the error keeps coming back."

    private val topics = listOf(
        Topic(listOf("battery", "charge", "charging", "drain", "bijli"), BATTERY, showStatus = true),
        Topic(listOf("slow", "lag", "hang", "freez", "frozen", "stuck"), SLOW),
        Topic(listOf("wifi", "wi-fi", "internet", "network", "mobile data", "connect"), CONNECTION),
        Topic(listOf("storage", "memory full", "no space", "space full"), STORAGE),
        Topic(listOf("hot", "heat", "overheat", "garam"), HEAT),
        Topic(listOf("crash", "stopping", "force close", "not working", "error", "bug"), CRASH),
        Topic(
            listOf("notification", "sound", "volume", "mute", "silent"),
            "Sound and notifications:\n" +
                "1. Check Do Not Disturb is off.\n" +
                "2. Press the volume keys and check media and ring volume.\n" +
                "3. Settings → Apps → the app → Notifications, to change them per app."
        ),
        Topic(
            listOf("bluetooth", "pair", "headphone", "earbud"),
            "Bluetooth fixes:\n" +
                "1. Turn Bluetooth off and on.\n" +
                "2. Forget the device and pair it again.\n" +
                "3. Restart both devices and keep them close."
        ),
        Topic(
            listOf("screenshot", "screen shot"),
            "Screenshot: press Power and Volume Down together. Many phones also allow a 3-finger swipe down."
        ),
        Topic(
            listOf("password", "otp", "pin", "bank", "upi", "card"),
            "For your safety, I'll never ask for passwords, OTPs, PINs or card details. " +
                "Only enter them in official apps, and never share them with anyone who calls you."
        )
    )

    private val greetingWords = setOf("hi", "hii", "hello", "hey", "namaste")
    private val thanksWords = setOf("thanks", "thank", "shukriya", "dhanyavad", "thx")
    private val whoWords = setOf("who", "name")

    /** Reply to a free-text message without any network. */
    fun answer(message: String, status: String): String {
        val text = message.lowercase()
        val words = text.split(Regex("[^a-z]+")).filter { it.isNotEmpty() }.toSet()

        topics.firstOrNull { t -> t.keys.any { text.contains(it) } }?.let { t ->
            val live = if (t.showStatus) "Right now: $status\n" else ""
            return "${Billu.ack.random()}\n$live${t.answer}"
        }
        if (words.any { it in greetingWords }) return Billu.idle.random()
        if (words.any { it in whoWords }) {
            return "I'm Billu. A ginger cat. I live on your phone. I'm offline right now, so I can help " +
                "with common phone problems. Mrrp."
        }
        if (words.any { it in thanksWords }) return Billu.pet.random()
        if (text.contains("joke")) return "Why did the phone break up with the charger? It needed more space."
        if (text.contains("bored") || text.contains("sad") || text.contains("tired") || text.contains("lonely")) {
            return "*sits next to you* I'm right here. ${Billu.idle.random()}"
        }
        return "${Billu.ack.random()} I don't know that one offline. Ask me about battery, a slow phone, " +
            "Wi-Fi, storage, overheating, app crashes, sound or Bluetooth. For free-form chat, add an API key " +
            "and connect to the internet."
    }

    /** Reply for a detected problem, used when the online AI is not available. */
    fun forProblem(p: Problem): String = "${Billu.OPENER}\n${tipFor(p.kind)}"

    private fun tipFor(kind: ProblemKind): String = when (kind) {
        ProblemKind.LOW_BATTERY -> BATTERY
        ProblemKind.NO_INTERNET -> CONNECTION
        ProblemKind.LOW_STORAGE -> STORAGE
        ProblemKind.APP_CRASH -> CRASH
        ProblemKind.APP_NOT_RESPONDING -> NOT_RESPONDING
        ProblemKind.SCREEN_ERROR -> SCREEN_ERROR
    }
}
