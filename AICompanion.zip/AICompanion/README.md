# AI Companion (Android)

A floating AI friend that lives on top of your screen.

- **Character-driven**: pick Sensei Panda, Captain Sparks, Luna, BOLT-7 or Chintu (Hinglish). Each has its own personality in chat and in how it reacts to alerts. Add more in `Characters.kt`.
- **Helps when something goes wrong**: warns you about low battery, lost internet, low storage, and (with the optional accessibility service) app crashes, "not responding" dialogs and error screens. Tap its speech bubble and it asks the AI for step-by-step fixes. Offline tips are built in.
- **Floats on screen**: draggable bubble that snaps to the screen edge. Tap to open the chat panel.

## Build and run

1. Install [Android Studio](https://developer.android.com/studio) (Koala or newer).
2. `File → Open` this folder and let Gradle sync (JDK 17 is bundled with Android Studio).
3. Connect an Android phone (USB debugging on) or use an emulator, then press Run.
4. In the app: paste your Claude API key (console.anthropic.com), choose a character, allow
   "Display over other apps", optionally enable problem detection, then tap **Start companion**.

Requires Android 8.0 (API 26) or newer.

## How it works

| File | Role |
| --- | --- |
| `MainActivity.kt` | Setup screen: key, character, permissions, start/stop |
| `FloatingService.kt` | Foreground service that draws the bubble, speech bubble and chat panel, and runs battery/network/storage checks |
| `ProblemWatcherService.kt` | Optional accessibility service that spots crash/error text in other apps |
| `AiClient.kt` | Calls the Claude Messages API (model set by `MODEL`) |
| `Characters.kt` | Personalities, problem types and offline fix tips |

## Privacy notes

- The API key is stored in app-private storage on the phone. For a public release, move it behind your own backend instead of shipping a user-entered key.
- The accessibility service only matches short error phrases on-device and skips text fields and password fields. Nothing is sent anywhere until you tap the companion for help, and then only the problem type, a short snippet and the app name are included.
- Some phone brands (Xiaomi, Oppo, Vivo, Samsung) aggressively kill background apps. If the bubble disappears, set the app's battery usage to "Unrestricted" and allow auto-start.

## Ideas to extend

- Voice input/output, idle chatter, per-character avatar images
- Screenshot-based help (MediaProjection) for "what's on my screen?"
- More detectors (slow Wi-Fi, overheating, Bluetooth failures)
